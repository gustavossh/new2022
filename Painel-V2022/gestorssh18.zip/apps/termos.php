<!doctype html>
<html lang="pt-br">
    <head>
        <!-- META SECTION -->
        <title>Apps</title>
        <meta name="title" content="ANUBIS PAINEL - Internet Ilimitada 5G">
        <meta name="description" content="ANUBIS PAINEL - Internet ilimitada de alta qualidade."> 
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- END META SECTION -->
    </head>
    
    <body style="
        background:#2a2b25; 
        color:#fff; 
        font-size:16px; 
        font-family: 'Roboto', sans-serif;">

        <style>
        a:link {
            color: white;  text-decoration: none;
        }

        a:visited {
            color: white;  text-decoration: none;
        }
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&amp;display=swap');

        </style>


        <center>
        <img src="./img/giphy.gif" style="height:140px;">
            <div style="
                font-size: 18px;
                color: red;
                border-bottom: 1px solid;
                width: 246px;
                padding: 4px; ">
				<h1>ANUBIS PAINEL<br>
				<br>
                <h2>TERMOS DE USO<br>
            </div></h2><br>
            
            <h4>
                • AO USAR NOSSO SERVIÇO, VOCÊ DEVE CONCORDAR COM TODOS OS NOSSOS TERMOS E CONDIÇÕES. VOCÊ DEVE ESTAR CIENTE DE QUE:<br><br>
                • O NOSSO SERVIÇO SE ISENTA DE QUAISQUER PROBLEMAS E LIMITAÇÕES DOS MODOS DE CONEXÃO AQUI UTILIZADOS, SEJA ELAS QUAIS FOR, COMO LENTIDÃO E INSTABILIDADES, OU MESMO QUEDAS, SEM DIREITO A POSSÍVEIS REEMBOLSOS, POIS O USUÁRIO ESTARÁ CIENTE DO QUÊ, E PARA QUE ESTÁ UTILIZANDO O APLICATIVO.<br><br>
                • CORREMOS SEMPRE ATRÁS DE MELHORAR, SE HOUVER QUEDA, VAMOS CORRER ATRÁS PRA CORRIGIR, MAS SE NÃO CONSEGUIMOS IREI AVISAR.<br><br>
                • SE VOCÊ REPASSAR SEU ACESSO A TERCEIROS E ENCONTRAMOS NO SISTEMA ULTRAPASSANDO O LIMITE CONTRATADO, VOCÊ TERA SEU ACESSO SUSPENSO SEM DIREITO A DEVOLUÇÃO DE DINHEIRO.<br><br>
                • PORQUE NÃO TEM DIREITO A REEMBOLSO? PORQUE NÃO TEMOS CULPA DA OPERADORA DERRUBAR O MÉTODO, E DAMOS SUPORTE A SERVIDOR  E APLICATIVO, E NÃO NA OPERADORA.<br><br>
                • VOCÊ CONCORDA QUE VOCÊ ACESSA E USA O SERVIÇO A SEU CRITÉRIO E RISCO.<br><br>
                • TODA RESPONSABILIDADE DE USO É SUA, NÃO SOMOS RESPONSÁVEL PELA REDE QUE VOCÊ ESTÁ A ACESSAR O SERVIÇO.
            </h4>
            <p class="copyright">&copy; 2021 - <script> document.write(new Date().getFullYear())</script><br> Todos os direitos reservados<br><a title="Styleshout" href="https://t.me/oogeniohacker">PAINEL ANUBIS</a></p>
    </body>
</html>
