<section id="multiple-column-form">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">UPLOAD DE APPS</h4>
<h4 class="img src animate__animated animate__backInDown"	<center><p><img src="/app-assets/images/avatars/avatar6.png" width="100%" height="100%"></p></center></h4>
					<a class="text-bold-800 grey darken-2" href="../apps" target="_blank">CLICK AQUI PARA IR PARA A LOJA DE APPS</a></span>
                </div>
                <div class="card-body">
<center><p class="px-0"><b>ADICIONAR APP 1.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeUpload.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
	   <p>
				</p>
    </form>
</div>
<center><p class="px-0"><b>ADICIONAR APP 2.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeUpload2.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form> 

<form method="post" action="recebe_upload3.php" enctype="multipart/form-data">
<label>ADICIONAR LOGO APP 1:</label>
<input type="file" name="arquivo" />
<input type="submit" value="ENVIAR" />
</form>

<form method="post" action="recebe_upload4.php" enctype="multipart/form-data">
<label>ADICIONAR LOGO APP 2:</label>
<input type="file" name="arquivo" />
<input type="submit" value="ENVIAR" />
</form>
                </div>
            </div>
        </div>
    </div>
</section>